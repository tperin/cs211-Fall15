#ifndef _fourth_h
#define _fourth_h

int **create(int,int);
void print(int**, int, int);

#endif
